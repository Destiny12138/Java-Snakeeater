    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lianxi1;

import java.util.Random;

/**
 *
 * @author 周安琪
 */
public class Blocks {
    int[][] t={ 
              {1,1,1,0,0,1,0,0,0,0,0,0,0,0,0,0},//黑色是1，白色是0，每四个为一行  凸
              {1,0,0,0,1,1,0,0,1,0,0,0,0,0,0,0},
              {0,1,0,0,1,1,1,0,0,0,0,0,0,0,0,0},
              {0,1,0,0,1,1,0,0,0,1,0,0,0,0,0,0}
    };
    int[][] i={//一条行
        {1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0},        
        {1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0}, 
        {1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0},
        {1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0} 
    };
    int[][] o={//正方形
       {1,1,0,0,1,1,0,0,0,0,0,0,0,0,0,0},
       {1,1,0,0,1,1,0,0,0,0,0,0,0,0,0,0},
       {1,1,0,0,1,1,0,0,0,0,0,0,0,0,0,0},
       {1,1,0,0,1,1,0,0,0,0,0,0,0,0,0,0}
    };
    int[][] w={//长条和方块
        {1,0,0,0,1,0,0,0,1,1,0,0,0,0,0,0},
        {1,1,1,0,0,0,1,0,0,0,0,0,0,0,0,0},
        {0,1,0,0,0,1,0,0,1,1,0,0,0,0,0,0},
        {0,1,0,0,0,1,0,0,1,1,0,0,0,0,0,0},
    };
    int[][] z={//叠放
        {1,1,0,0,0,1,1,0,0,0,0,0,0,0,0,0},
        {0,1,1,0,1,1,0,0,0,0,0,0,0,0,0,0},
        {0,1,0,0,1,1,0,0,1,0,0,0,0,0,0,0},
        {1,0,0,0,1,1,0,0,0,1,0,0,0,0,0,0}
    };
    public int[][]total(){
        Random r=new Random();
        int num=0;
        int num1=r.nextInt(125);
        if(num1<25){
            num=0;
        }
        else if(num1<50){
            num=1;
        }
        else if(num1<75){
            num=2;
        }
         else if(num1<100){
            num=3;
        }
         else if(num1<125){
            num=4;
        }
        switch(num){
            default:
            return i;
            case 0:
            return t;
             case 1:
            return i;
             case 2:
            return o;
             case 3:
            return w;
             case 4:
            return z;
        }
    }
}
