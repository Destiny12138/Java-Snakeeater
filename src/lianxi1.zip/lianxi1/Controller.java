/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lianxi1;

import static java.lang.Thread.sleep;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 周安琪
 */
public class Controller extends Thread{
    GamePanel gp;//创建一个GamePanel
    int[][] blocks;
    int status=0;
    Blocks bl=new Blocks();
    public Controller(GamePanel gp){//构造方法
        this.gp=gp;
       blocks=bl.total();
        gp.block=blocks[status];
    }
    
    public void theBlockFinish(){
        for(int i=0;i<4;i++)
             for(int j=0;j<4;j++){
                 if(gp.block[4*i+j]==1){
                     gp.fixBlocks[gp.y/20+i][gp.x/20+j]=1;
                 }
             }
                   gp.x=40;
                   gp.y=0;
                   blocks=bl.total();
                   gp.block=blocks[status];
    }
public void clearBlocks(int[][] blocks){
    int mark=0;
    for(int i=0;i<20;i++){
        for(int j=0;j<10;j++){
            if(blocks[i][j]==0)mark++;
        }
        if(mark==0){
            for(int j=0;j<10;j++){
                gp.fixBlocks[i][j]=0;
            }
            for(int l=i-1;l>=0;l--){
                for(int m=0;m<10;m++){
                    if(gp.fixBlocks[l][m]==1){
                        gp.fixBlocks[l][m]=0;
                        gp.fixBlocks[l+1][m]=1;
                    }
                }
            }
        }
        mark=0;
        }
    }
    public boolean isOverStep(int x,int y,int[]block){
        boolean flag=false;
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++){
                 if(block[4*i+j]==1&&((x+j*20<0)||(x+j*20)>180||(y+i*20)>380)){//有问题2 200 3 400
            flag=true;
        }
            }
        }
       
        return flag;
    }
public boolean isOverStep2(int x,int y,int[] block){
    for(int i=0;i<4;i++){
        for(int j=0;j<4;j++){
            if(block[4*i+j]==1&&gp.fixBlocks[y/20+i][x/20+j]==1){
               return true;
            }
        }
    }
    return false;
}
    public void left(){
        if(isOverStep(gp.x-20,gp.y,gp.block)!=true&&isOverStep2(gp.x-20,gp.y,gp.block)!=true){
            gp.x-=20;
        gp.repaint();  
        }
    }
    public void right(){
        if(isOverStep(gp.x+20,gp.y,gp.block)!=true&&isOverStep2(gp.x+20,gp.y,gp.block)!=true){
        gp.x+=20;
        gp.repaint();  
        }
    }
    public void down(){
         if(isOverStep(gp.x,gp.y+20,gp.block)!=true&&isOverStep2(gp.x,gp.y+20,gp.block)!=true){
        gp.y+=20;
        gp.repaint(); 
         }
         else{
             theBlockFinish();
         }
    }
   public void turn(){
    int temp=status;
       status++;
      if(status==blocks.length)status=0;
      if(isOverStep(gp.x,gp.y,blocks[status])!=true){
          gp.block=blocks[status];
          gp.repaint();
      }else{
          status=temp;
      }
   }
   
   public void run(){
       for(int i=0;i<500;i++){
           try {
               down();
               sleep(800);
               clearBlocks(gp.fixBlocks);
           } catch (InterruptedException ex) {
               Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
           }
       }
}
}

